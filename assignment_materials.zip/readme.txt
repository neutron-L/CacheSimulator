***********************************************************
Lab 3

Group: (Please put your name and netid here)

Student1 (netid1)
Student2 (netid2)

Reference: (Include the reference you use)


***********************************************************

This is the directory for students. 

It should contain these following files:

.
├── Makefile
├── cacheconfig.txt
├── cachesimulator.cpp
├── expected_results
│   └── trace.txt.out.ans.txt
├── Lab3.pdf
├── readme.txt
└── trace.txt


If you test with the cacheconfig.txt and trace.txt:
./cachesimulator.out cacheconfig.txt trace.txt
you should receive the output as in ./expected_results

***********************************************************
